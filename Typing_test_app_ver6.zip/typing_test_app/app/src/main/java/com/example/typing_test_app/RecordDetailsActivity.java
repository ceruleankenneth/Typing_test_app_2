package com.example.typing_test_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RecordDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_details);
    }
}