package com.example.typing_test_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class CharHistory1Activity extends AppCompatActivity {
    ImageButton backbutton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_char_history1);


        backbutton2 =findViewById(R.id.back_button_history_Character1);
        backbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(CharHistory1Activity.this,TestHistoryActivity.class);
                startActivity(i);
            }
        });
    }

}